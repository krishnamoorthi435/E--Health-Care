from django.contrib import admin
from patient.models import *
# Register your models here.
admin.site.register(Profile)
admin.site.register(Disease1)
admin.site.register(Heart) 
admin.site.register(Diabetes)
admin.site.register(Image)
admin.site.register(WhoPredictDisease)
admin.site.register(Feedback)

