from django.apps import AppConfig


class RoleadminConfig(AppConfig):
    name = 'roleadmin'
